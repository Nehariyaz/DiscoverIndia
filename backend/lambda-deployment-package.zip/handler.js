// handler.js
const serverlessExpress = require('@vendia/serverless-express');
const app = require('./index');  // Import Express app

// Export the Lambda handler wrapped by serverless-express
exports.handler = serverlessExpress({ app });
