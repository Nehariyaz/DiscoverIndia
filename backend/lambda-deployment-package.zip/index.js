// index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const connectDB = require('./config/db'); // Adjusted as per above
const EmailLog = require('./models/EmailLog');
const User = require('./models/User');
const { verifyRecaptcha } = require('./utils/recaptcha');
const recommendationRoutes = require('./routes/recommendations');
const destinationRoutes = require('./routes/destination');
const chatbotRoutes = require('./routes/chatbot');
const UserPreference = require('./models/UserPreference');

const app = express();

// Connect to DB once when module loads (cache handled inside connectDB)
connectDB().catch(err => {
  console.error("Initial DB connection failed", err);
  // Depending on your app strategy, process.exit(1) here or just log
});

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Reuse nodemailer transporter outside route handlers to avoid re-instantiation
const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});

// Routes
app.use('/api/destinations', destinationRoutes);
app.use('/api/recommendations', recommendationRoutes);
app.use('/api/chatbot', chatbotRoutes);

app.post('/enquiry', async (req, res) => {
  console.log('Received enquiry:', req.body);

  const { name, email, subject, message, recaptchaToken } = req.body;

  try {
    // Optional: Verify reCAPTCHA here if you want

    await transporter.sendMail({
      from: `"${name}" <${email}>`,
      to: process.env.GMAIL_USER,
      subject: subject || "New Travel Enquiry",
      text: message,
    });

    await EmailLog.create({
      name,
      email,
      subject,
      message,
      status: "success",
    });

    res.status(200).json({ message: "Enquiry sent successfully" });
  } catch (error) {
    console.error('Error sending enquiry:', error);

    await EmailLog.create({
      name,
      email,
      subject,
      message,
      status: "failure",
      error: error.message,
    });

    res.status(500).json({ error: "Failed to send enquiry", details: error.message });
  }
});

app.post('/signup', async (req, res) => {
  const { firstName, lastName, email, password, recaptchaToken } = req.body;

  if (!recaptchaToken) {
    return res.status(400).json({ error: "Missing reCAPTCHA token" });
  }

  const isHuman = await verifyRecaptcha(recaptchaToken);
  if (!isHuman) {
    return res.status(400).json({ error: "Failed reCAPTCHA verification" });
  }

  try {
    const emailNormalized = email.toLowerCase().trim();

    const existingUser = await User.findOne({ email: emailNormalized });
    if (existingUser) {
      return res.status(409).json({ error: "User already exists with this email" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({
      firstName,
      lastName,
      email: emailNormalized,
      password: hashedPassword
    });

    await newUser.save();

    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, {
      expiresIn: '2h'
    });

    console.log('User registered:', emailNormalized);
    res.status(200).json({
      message: "Signup successful",
      userId: newUser._id,
      token,
    });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ error: "Signup failed", details: err.message });
  }
});

app.post('/login', async (req, res) => {
  const { email, password, recaptchaToken } = req.body;

  // Optional: add reCAPTCHA validation here as on signup

  try {
    const emailNormalized = email.toLowerCase().trim();
    const user = await User.findOne({ email: emailNormalized });

    if (!user) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: '2h',
    });

    res.status(200).json({
      message: "Login successful",
      userId: user._id,
      token,
    });
  } catch (error) {
    console.error('Login failed:', error);
    res.status(500).json({
      success: false,
      message: "Login failed",
      error: error.message,
    });
  }
});

app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  try {
    const emailNormalized = email.toLowerCase().trim();

    const user = await User.findOne({ email: emailNormalized });
    if (!user) {
      // Do not reveal user existence
      return res.status(200).json({ message: 'If your email exists, you will receive a reset link.' });
    }

    const resetToken = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    const resetLink = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;

    await transporter.sendMail({
      from: `"Support" <${process.env.GMAIL_USER}>`,
      to: emailNormalized,
      subject: 'Password Reset Request',
      text: `You requested a password reset. Click to reset your password: ${resetLink}`,
      html: `<p>You requested a password reset.</p><p>Click to reset your password:</p><a href="${resetLink}">${resetLink}</a>`
    });

    await EmailLog.create({
      name: 'Password Reset',
      email: emailNormalized,
      subject: 'Password Reset Request',
      message: `Reset link sent: ${resetLink}`,
      status: 'success'
    });

    res.json({ message: 'Reset link sent successfully' });
  } catch (error) {
    console.error('Forgot password error:', error);

    await EmailLog.create({
      name: 'Password Reset',
      email: email,
      subject: 'Password Reset Request',
      message: error.message,
      status: 'failure',
      error: error.message
    });

    res.status(500).json({ error: 'Failed to send reset link', details: error.message });
  }
});

app.post('/reset-password', async (req, res) => {
  const { token, password } = req.body;

  if (!token || !password) {
    return res.status(400).json({ error: 'Token and new password are required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(400).json({ error: 'Invalid token or user not found' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    user.password = hashedPassword;
    await user.save();

    res.status(200).json({ message: 'Password reset successful' });
  } catch (error) {
    console.error('Reset password error:', error);

    if (error.name === 'TokenExpiredError') {
      return res.status(400).json({ error: 'Reset token has expired' });
    }

    res.status(400).json({ error: 'Invalid token' });
  }
});

app.post('/api/preferences', async (req, res) => {
  try {
    console.log('Full Request Body:', req.body);

    if (!req.body.userId || !req.body.travelType) {
      return res.status(400).json({ error: 'Missing fields in preferences' });
    }

    const newPreference = new UserPreference(req.body);
    await newPreference.save();

    res.status(200).json({ success: true });
  } catch (err) {
    console.error('Error inserting preferences:', err.stack || err.message);
    res.status(500).json({ error: 'Failed to save preferences' });
  }
});

// Global error handler middleware (to catch unexpected errors)
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

const PORT = process.env.PORT || 5000;

// Export app differently for Lambda / local usage
if (require.main === module) {
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
} else {
  module.exports = app;
}
